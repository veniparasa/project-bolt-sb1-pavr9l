import { FaGithub, FaLinkedin } from 'react-icons/fa';
import { SiCodechef } from 'react-icons/si';

export default function Header() {
  return (
    <header className="bg-gray-900 text-white py-8">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-2">Samudra Veni Parasa</h1>
        <div className="mb-4">
          <p className="text-gray-300">📧 veniparasa@gmail.com</p>
          <p className="text-gray-300">📱 +91 9182488433</p>
          <p className="text-gray-300">📍 Hyderabad</p>
        </div>
        <div className="flex space-x-4">
          <a href="https://github.com/veniparasa" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400">
            <FaGithub size={24} />
          </a>
          <a href="https://www.linkedin.com/in/samudra-veni-parasa-a831672a6/" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400">
            <FaLinkedin size={24} />
          </a>
          <a href="https://www.codechef.com/users/veniparasa16" target="_blank" rel="noopener noreferrer" className="hover:text-gray-400">
            <SiCodechef size={24} />
          </a>
        </div>
      </div>
    </header>
  );
}