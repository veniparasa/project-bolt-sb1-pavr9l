export default function Education() {
  const education = [
    {
      institution: "Koneru Lakshmaiah University",
      degree: "B.Tech",
      period: "2023-2027",
      current: true
    },
    {
      institution: "Sri Chaitanya Junior College",
      degree: "Intermediate",
      period: "2021"
    },
    {
      institution: "Sri Chaitanya Techno School",
      degree: "School Education",
      period: "2021-2023"
    }
  ];

  return (
    <section className="py-8 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-6">Education</h2>
        <div className="space-y-4">
          {education.map((edu, index) => (
            <div key={index} className="border-l-4 border-gray-900 pl-4">
              <h3 className="font-semibold text-lg">{edu.institution}</h3>
              <p className="text-gray-600">{edu.degree}</p>
              <p className="text-gray-500">{edu.period}</p>
              {edu.current && (
                <span className="inline-block bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                  Current
                </span>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}