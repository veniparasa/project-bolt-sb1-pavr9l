export default function Skills() {
  return (
    <section className="py-8 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold mb-6">Skills & Interests</h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Languages</h3>
            <ul className="list-disc list-inside space-y-2">
              <li>Telugu</li>
              <li>Hindi</li>
              <li>English</li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Hobbies</h3>
            <ul className="list-disc list-inside space-y-2">
              <li>Listening to music</li>
              <li>Writing stories and novels</li>
              <li>Building mini projects</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}