import Header from './components/Header';
import Education from './components/Education';
import Skills from './components/Skills';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <Education />
        <Skills />
      </main>
      <footer className="bg-gray-900 text-white py-4 text-center">
        <p>© 2024 Samudra Veni Parasa. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;